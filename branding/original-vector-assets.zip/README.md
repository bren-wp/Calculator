# Calculator — Full Android Branding Kit

**Official app name:** Calculator  
**Language:** English only  
**Design:** Flat 2D, no 3D, no gradients, no neon, no floating decoration.

## Launch flow

Android system splash → Standard Calculator. No onboarding, sign-in, or intermediate screens.

## Contents

- `screens/png/` — every screen as an individual full-resolution 1296 × 2880 PNG.
- `screens/svg/` — individually editable SVG versions of all screens.
- `brand/` — launcher icon variants (dark, light, AMOLED, monochrome), adaptive foreground, wordmark, brand guide.
- `play_store/` — 1024 × 500 feature graphic and four promotional compositions.
- `all_screens_contact_sheet.png` — convenient visual index.
- `design_tokens_and_screen_manifest.json` — palette, screens, and specifications.

## User experience

The first launch immediately opens the Standard calculator after the splash. Standard, Scientific, and Programmer share the same primary layout; Tools and History are reachable in bottom navigation. Settings controls themes, precision, vibration, sound, shortcuts, and privacy.

## Default calculator limitations on Android

Android provides `android.intent.category.APP_CALCULATOR` for launching calculator apps; register support correctly. There is **no universal public default-calculator role** that can be forced on all Android devices. Device and launcher behavior varies. Provide genuine shortcuts/widgets and explain limitations without an unimplementable “Set as default” button.

## Engineering guidance

Implement these as responsive native UI layouts. Render all buttons from a shared design system using Android Compose, include edge-to-edge insets, content descriptions, TalkBack support, scalable text, and verified calculation logic. The provided screens are **branding and UI concepts**, not a working APK.

Currency rates depicted are **illustrative**, not real-time. Do not suggest that history is private/offline unless the app implementation indeed stores it locally and does not transmit it.
